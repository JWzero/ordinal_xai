from setuptools import setup

# This is a minimal setup.py that defers to pyproject.toml
# All package configuration should be in pyproject.toml

if __name__ == "__main__":
    setup()